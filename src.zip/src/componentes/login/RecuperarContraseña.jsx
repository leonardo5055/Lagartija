import React, { useState } from 'react';
import axios from 'axios';
import Footer from '../estructura/Footer';
import Nav from '../estructura/Nav';
import './estilo/RecuperarContraseña.css';

function RecuperarContraseña() {
  const [correo, setCorreo] = useState("");
  const [mensaje, setMensaje] = useState("");
  const [error, setError] = useState('');

  const manejarEnvio = async (e) => {
    e.preventDefault();
    setMensaje('');  // Resetea los mensajes anteriores
    setError('');
    try {
      // Reemplaza esta URL con la dirección correcta de tu API
      const response = await axios.post('http://localhost:3000/RecuperarContrase%C3%B1a', { correo });

      if (response.status === 200) {
          setMensaje('Se ha enviado un enlace de recuperación a tu correo electrónico.');
      }
    } catch (error) {
      if (error.response && error.response.status === 404) {
          setError('No se encontró una cuenta con ese correo electrónico.');
      } else {
          setError('Ocurrió un error al procesar tu solicitud. Por favor, inténtalo de nuevo más tarde.');
      }
  }
};


  return (
    <div>
      <Nav />
      <div className='recupererar-contra-container'>
        <div className='recuperar-contra-card'>
          <div className='icono-de-candado'>
            <i className='fas fa-lock'></i>
          </div>
          <p className='desc'>
            ¿Tienes problemas para entrar? Introduce tu correo electrónico, número de teléfono o nombre de usuario y te enviaremos un enlace para que vuelvas a entrar en tu cuenta.
          </p>
          <form onSubmit={manejarEnvio}>
            <input
              type="text"
              className="form-control entrada-cuenta"
              placeholder="Correo electrónico, teléfono o usuario"
              value={correo}
              onChange={(e) => setCorreo(e.target.value)}
            />
            <button type="submit" className="btn btn-primary btn-enviar">Enviar enlace de acceso</button>
          </form>
          {mensaje && <p className="mensaje mt-3">{mensaje}</p>}
          <hr className='separador' />
          <a href="/crear-cuenta" className='crear-cuenta-nueva'>Crear Cuenta Nueva</a>
        </div>
      </div>
      <Footer />
    </div>
  );
}

export default RecuperarContraseña;
